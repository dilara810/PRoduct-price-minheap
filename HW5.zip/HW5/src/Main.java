/* Dilara TOSUN - 20050111041*/
import java.io.*;
import java.util.Arrays;
class BinaryMinHeap {
    private Product[] products;
    private int maxCapacity;
    private int numberOfElements;
    public BinaryMinHeap(int maxCapacity) {
        this.maxCapacity = maxCapacity;
        products = new Product[maxCapacity];
        numberOfElements = 0;
    }
    private int parent(int key) {return (key - 1) / 2;}
    private int left(int key) {return 2 * key + 1;}
    private int right(int key) {return 2 * key + 2;}
    public void Add(String name, double price) {
        ensureExtraCapacity();
        Product product = new Product(name, price);
        for (Product value : products) {
            if (value != null && value.getName().equals(product.getName())) {
                System.out.println("The product cannot be added.");
                return;
            }
        }
        products[numberOfElements] = product;
        numberOfElements++;
        heapifyUp(numberOfElements - 1);
        System.out.println(product.getName() + " with price " + product.getPrice() + " added.");
    }

    public void removeMin() {
        if (numberOfElements == 0) {
            System.out.println("Error, no item added yet.");
        } else {
            double minPrice = products[0].getPrice();
            while (numberOfElements > 0 && products[0].getPrice() == minPrice) {
                Product minProduct = products[0];
                products[0] = products[numberOfElements - 1];
                numberOfElements--;
                heapifyDown(0);
                System.out.println(minProduct.getName() + " is removed since it has the min price");
            }
        }
    }

    public String listMin() {
        if (numberOfElements == 0) {
            return "Error, no item added yet.";
        } else {
            Product minProduct = products[0];
            String priceString = String.format("%.2f", minProduct.getPrice()).replace(",", ".");
            return minProduct.getName() + " with price " + priceString + " listed (without removing).";
        }
    }

    public void decreasePrice(String name, double amount) {
        if (numberOfElements == 0) {
            System.out.println("Error, no item added yet.");
        } else {
            for (int i = 0; i < numberOfElements; i++) {
                if (products[i].getName().equals(name)) {
                    products[i].setPrice(products[i].getPrice() - amount);
                    String newPriceString = String.format("%.2f", products[i].getPrice()).replace(",", ".");;
                    System.out.println(products[i].getName() + "'s price is decreased by " + amount +
                            " (making it " + newPriceString + ").");
                    heapifyUp(i);
                    break;
                }
            }
        }
    }

    private void ensureExtraCapacity() {
        if (numberOfElements == maxCapacity) {
            products = Arrays.copyOf(products, maxCapacity * 2);
            maxCapacity *= 2;
        }
    }
    private void heapifyUp(int index) {
        int current = index;
        while (current > 0 && products[current].getPrice() < products[parent(current)].getPrice()) {
            swap(current, parent(current));
            current = parent(current);
        }
    }
    private void heapifyDown(int index) {
        int smallest = index;
        int left = left(index);
        int right = right(index);
        if (left < numberOfElements && products[left].getPrice() < products[smallest].getPrice()) {smallest = left;}
        if (right < numberOfElements && products[right].getPrice() < products[smallest].getPrice()) {smallest = right;}
        if (smallest != index) {
            swap(index, smallest);
            heapifyDown(smallest);
        }
    }
    private void swap(int i, int j) {
        Product temp = products[i];
        products[i] = products[j];
        products[j] = temp;
    }

    public void query(String command) {
        String[] parts = command.split(" ");
        String operation = parts[0];
        switch (operation) {
            case "Add" -> Add(parts[1], Double.parseDouble(parts[2]));
            case "ListMin" -> System.out.println(listMin());
            case "RemoveMin" -> removeMin();
            case "DecreasePrice" -> decreasePrice(parts[1], Double.parseDouble(parts[2]));
            default -> throw new IllegalArgumentException("Unexpected operation: " + operation);
        }
    }
    public void readList() {
        try (BufferedReader br = new BufferedReader(new FileReader("process.txt"))) {
            String line = br.readLine();

            if(line == null) System.out.println("The file is empty!");
            else query(line);

            while ((line = br.readLine()) != null) {
                query(line);
            }
        } catch (IOException e) {
            throw new RuntimeException("File is not found!");
        }
    }
}
class Product {
    private String name;
    private double price;
    public Product(String name, double price) {
        this.name = name;
        this.price = price;
    }
    public String getName() {return name;}
    public double getPrice() {return price;}
    public void setPrice(double price) {this.price = price;}
}
public class Main {
    public static void main(String[] args) {
        BinaryMinHeap heap = new BinaryMinHeap(10);
        heap.readList();
    }
}
